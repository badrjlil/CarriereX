package com.iga.belvedere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarriereXApplicationTests {

	@Test
	void contextLoads() {
	}

}
