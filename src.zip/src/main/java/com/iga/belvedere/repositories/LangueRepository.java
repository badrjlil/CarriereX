package com.iga.belvedere.repositories;

import org.springframework.data.jpa.repository.JpaRepository; 
import com.iga.belvedere.entities.Langue;

public interface LangueRepository extends JpaRepository<Langue,Integer> {

}
